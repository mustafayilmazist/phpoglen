-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 03 Mar 2020, 18:56:42
-- Sunucu sürümü: 10.1.35-MariaDB
-- PHP Sürümü: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `yapilacaklar`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `log`
--

CREATE TABLE `log` (
  `log_id` int(11) NOT NULL,
  `log_aciklama` text COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yapilacak`
--

CREATE TABLE `yapilacak` (
  `yapilacak_id` int(11) NOT NULL,
  `yapilacak_baslik` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `yapilacak_icerik` text COLLATE utf8_turkish_ci NOT NULL,
  `yapilacak_durum` varchar(25) COLLATE utf8_turkish_ci NOT NULL COMMENT 'yapılacak,yapılmış,ertelenmiş'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yapilacak`
--

INSERT INTO `yapilacak` (`yapilacak_id`, `yapilacak_baslik`, `yapilacak_icerik`, `yapilacak_durum`) VALUES
(39, 'mama al', '', 'yapıldı'),
(40, 'Ödevi Unutma', 'Mustafa Hocanın php dersi ödevini yap', 'ertelenmiş'),
(41, 'Eve Git', '', 'yapılacak');

--
-- Tetikleyiciler `yapilacak`
--
DELIMITER $$
CREATE TRIGGER `delete_log` AFTER DELETE ON `yapilacak` FOR EACH ROW BEGIN
	INSERT INTO log(log_id,log_aciklama)
    VALUES (NULL,Concat (OLD.yapilacak_id, ' id değerine sahip, ',OLD.yapilacak_baslik,' ',OLD.yapilacak_icerik,' ', OLD.yapilacak_durum,' içeriğine sahip kayıt ', NOW(),' tarihinde silindi.'));
END
$$
DELIMITER ;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`log_id`);

--
-- Tablo için indeksler `yapilacak`
--
ALTER TABLE `yapilacak`
  ADD PRIMARY KEY (`yapilacak_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `log`
--
ALTER TABLE `log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `yapilacak`
--
ALTER TABLE `yapilacak`
  MODIFY `yapilacak_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
