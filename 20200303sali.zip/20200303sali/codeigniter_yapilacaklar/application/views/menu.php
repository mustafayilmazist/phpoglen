<div class="row my-4">
	<div class="col-lg-12">
		<a href="<?php echo base_url("yapilacaklar"); ?>" class="btn btn-danger">Yapılacaklar</a>
		<a href="<?php echo base_url("yapilmislar"); ?>" class="btn btn-success">Yapılmışlar</a>
		<a href="<?php echo base_url("ertelenenler"); ?>" class="btn btn-warning">Ertelenler</a>
		<a href="<?php echo base_url("tumu"); ?>" class="btn btn-info">Tümü</a>
	</div>
</div>