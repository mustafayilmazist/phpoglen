<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<?php $this->load->view("nav"); ?>
	<div class="container">
		<?php $this->load->view("menu"); ?>
		<?php 
		if($this->session->flashdata("message")){
			?>
			<div class="alert alert-<?php echo $this->session->flashdata("type");?>">
				<strong><?php echo $this->session->flashdata("title");?></strong>
				<?php echo strip_tags($this->session->flashdata("message"),"<br>");?>
			</div>
			<?php
		}
		?>
		<div class="row my-4">
			<div class="col-lg-12">
				<div class="page-header">
					<h1>Tüm Yapılacaklar</h1>
				</div>
				<?php 
				if ($tum_yapilacaklar!=false) {
					?>
					<div class="page-body">
						<table class="table table-hover">
							<tr>
								<th>No</th>
								<th>Başlık</th>
								<th>İçerik</th>
								<th style="width: 150px;"></th>
							</tr>
							<?php foreach ($tum_yapilacaklar as $key => $value) { ?>
								<tr>
									<td><?php echo $key+1; ?></td>
									<td><?php echo $value["yapilacak_baslik"]; ?></td>
									<td><?php echo $value["yapilacak_icerik"]; ?></td>
									<td>
										<a href="<?php echo base_url("yapilacaklar/islem/{$value["yapilacak_id"]}/yap"); ?>" class="btn btn-success">
											Yap
										</a>
										<a href="<?php echo base_url("yapilacaklar/islem/{$value["yapilacak_id"]}/ertele"); ?>" class="btn btn-warning">
											Ertele
										</a>
									</td>
								</tr>
							<?php } ?>
						</table>
					</div>
					<?php 
				}
				?>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>	
</body>
</html>