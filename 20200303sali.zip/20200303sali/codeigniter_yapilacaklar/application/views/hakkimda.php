<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<?php $this->load->view("nav"); ?>
	<div class="container">
		<div class="row my-4">
			<div class="col-lg-12">
				<div class="page-header">
					<h1>Hakkımda</h1>
				</div>
				<div class="page-body">
					<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat ducimus magni velit dignissimos eaque ex? Aperiam inventore sint porro dolorem soluta aliquid quisquam nam, ipsum, omnis fugiat blanditiis, cumque minus.</div>
					<div>Beatae nesciunt, veniam reprehenderit sequi unde, nam cupiditate voluptatibus quas facere placeat explicabo perferendis exercitationem ad tempore. Repellat voluptatibus praesentium voluptate veritatis a ipsum vel laudantium sequi autem unde. Numquam.</div>
					<div>Odit eveniet ullam tenetur quae, culpa! Maiores temporibus impedit praesentium deserunt quae voluptatem, quos hic esse beatae provident, pariatur reiciendis expedita, quibusdam consequatur eaque eveniet libero fugiat distinctio voluptatibus totam.</div>
					<div>Blanditiis quae quibusdam optio fugiat dolor dolore dolorem iure. Corporis eligendi voluptas repudiandae, incidunt quidem nemo totam nihil in voluptatum voluptatem eaque! Consequatur ea, labore illo consectetur dignissimos ipsa soluta.</div>
					<div>Distinctio harum omnis aperiam dolorum laborum, placeat natus dicta aliquid voluptatum ad aliquam, sit adipisci debitis fugit iusto, blanditiis doloremque consectetur quod! Ab magnam dolorem, similique animi obcaecati doloribus sit.</div>
				</div>
			</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>	
</body>
</html>