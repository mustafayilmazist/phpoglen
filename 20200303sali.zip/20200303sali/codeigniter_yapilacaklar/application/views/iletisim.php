<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<?php $this->load->view("nav"); ?>
	<div class="container">
		<div class="row my-4">
			<div class="col-lg-12">
				<div class="page-header">
					<h1>İletişim</h1>
				</div>
				<div class="page-body">
					<form class="form-horizontal">
						<fieldset>

							<!-- Text input-->
							<div class="form-group">
								<label class="control-label" for="adsoyad">Ad Soyad</label>  
									<input id="adsoyad" name="adsoyad" type="text" placeholder="Mustafa Yılmaz" class="form-control input-md">
							</div>

							<!-- Text input-->
							<div class="form-group">
								<label class="control-label" for="email">E-Mail</label>  
								<input id="email" name="email" type="text" placeholder="mustafa@mustafa.com" class="form-control input-md">
							</div>

							<!-- Text input-->
							<div class="form-group">
								<label class="control-label" for="konu">Konu</label>  
								<input id="konu" name="konu" type="text" placeholder="Yardım" class="form-control input-md">
							</div>

							<!-- Textarea -->
							<div class="form-group">
								<label class="control-label" for="mesaj">Mesajınız</label>
								<textarea class="form-control" id="mesaj" name="mesaj">Yardım İstiyorum</textarea>
							</div>

							<!-- Button -->
							<div class="form-group">
								<label class="control-label" for=""></label>
								<button id="" name="" class="btn btn-primary">Mesajı Gönder</button>
							</div>

						</fieldset>
					</form>

				</div>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>	
</body>
</html>