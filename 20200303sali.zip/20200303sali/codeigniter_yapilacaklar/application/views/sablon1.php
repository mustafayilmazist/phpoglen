<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Document</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<?php $this->load->view("nav"); ?>
	<div class="container">
		<?php $this->load->view("menu"); ?>
		<div class="row my-4">
			<div class="col-lg-12">
				<div class="page-header">
					<h1>Yapılacaklar Girişi</h1>
				</div>
				<div class="page-body">
					<form action="" method="post">
						<div class="form-group">
							<label for="">Başlık</label>
							<input type="text" name="baslik" class="form-control">
						</div>
						<div class="form-group">
							<label for="">İçerik</label>
							<input type="text" name="baslik" class="form-control">
						</div>
						<input type="submit" value="Ekle" class="btn btn-primary">
					</form>
				</div>
			</div>
		</div>
		<div class="row my-4">
			<div class="col-lg-12">
				<div class="page-header">
					<h1>Son 5 Yapılacaklar</h1>
				</div>
				<div class="page-body">
					<table class="table table-hover">
						<tr>
							<th>No</th>
							<th>Başlık</th>
							<th>İçerik</th>
						</tr>
						<tr>
							<td>1</td>
							<td>Başlık</td>
							<td>İçerik</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>	
</body>
</html>