<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Yapilacak_model extends CI_Model {

	public function ekle($data)
	{
		return $this->db->insert("yapilacak",$data);
	}

	public function son5Yapilacak($limit)
	{
		return $this->db->where("yapilacak_durum","yapılacak")
		->order_by("yapilacak_id","desc")
		->get("yapilacak",$limit)
		->result_array();
	}
	public function tumYapilacaklar($where=array())
	{
		return $this->db->where($where)
		->order_by("yapilacak_id","desc")
		->get("yapilacak")
		->result_array();
	}
	public function islem($data,$where)
	{
		return $this->db->where($where)->update("yapilacak",$data);
	}

}
