<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Yapilacaklar extends CI_Controller {
	public function index()
	{
		$data["tum_yapilacaklar"]=$this->yapilacak_model->tumYapilacaklar(
			array(
				"yapilacak_durum"=>"yapılacak"
			)
		);
		$this->load->view('yapilacaklar',$data);
	}
	public function islem($id="",$islem="")
	{
		if (!is_numeric($id) or $islem=="") {
			redirect($this->agent->referrer());
		}
		switch ($islem) {
			case 'yap':
			$guncelle = $this->yapilacak_model->islem(
				array(
					"yapilacak_durum"=>	"yapıldı"
				),
				array(
					"yapilacak_id"=>$id
				)
			);
			if ($guncelle) {
				$this->session->set_flashdata("type","success");
				$this->session->set_flashdata("title","Başarılı");
				$this->session->set_flashdata("message","Değişiklikler Eklendi..");
			}else{
				$this->session->set_flashdata("type","danger");
				$this->session->set_flashdata("title","Başarısız");
				$this->session->set_flashdata("message","Değişiklikler Eklenemedi..");
			}
			break;
			case 'ertele':
			$guncelle = $this->yapilacak_model->islem(
				array(
					"yapilacak_durum"=>	"ertelenmiş"
				),
				array(
					"yapilacak_id"=>$id
				)
			);
			if ($guncelle) {
				$this->session->set_flashdata("type","success");
				$this->session->set_flashdata("title","Başarılı");
				$this->session->set_flashdata("message","Değişiklikler Eklendi..");
			}else{
				$this->session->set_flashdata("type","danger");
				$this->session->set_flashdata("title","Başarısız");
				$this->session->set_flashdata("message","Değişiklikler Eklenemedi..");
			}
			break;

		}
		redirect(base_url("yapilacaklar"));
	}
}