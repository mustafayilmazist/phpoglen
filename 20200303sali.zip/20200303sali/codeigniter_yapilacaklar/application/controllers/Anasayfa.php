<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Anasayfa extends CI_Controller {
	public function index()
	{
		$data["son5yapilacak"]=$this->yapilacak_model->son5Yapilacak(5);
		$this->load->view('anasayfa',$data);
	}
	public function ekleForm()
	{

		if ($this->input->post()) {
			$this->form_validation->set_rules('baslik','Başlık','trim|required|min_length[5]');
			$this->form_validation->set_message(
				array(
					'required'=>"{field} boş bırakılamaz..",
					'min_length'=>"{field} en az {param} karakter olmalıdır."
				)
			);
			if ($this->form_validation->run()) {
				$ekle = $this->yapilacak_model->ekle(
					array(
						"yapilacak_baslik"=>$this->input->post("baslik"),
						"yapilacak_icerik"=>$this->input->post("icerik"),
						"yapilacak_durum"=>'yapılacak'
					)
				);
				if ($ekle) {
					$this->session->set_flashdata("type","success");
					$this->session->set_flashdata("title","Başarılı");
					$this->session->set_flashdata("message","Bilgiler Eklendi..");
				}else{
					$this->session->set_flashdata("type","danger");
					$this->session->set_flashdata("title","Başarısız");
					$this->session->set_flashdata("message","Bilgiler Eklenemedi..");
				}
			}else{
				
				$this->session->set_flashdata("type","warning");
				$this->session->set_flashdata("title","Uyarı");
				$this->session->set_flashdata("message",validation_errors());
			}
		}
		redirect(base_url("anasayfa"));
	}
}